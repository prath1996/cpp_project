#ifndef CPP_PROJECT_READER_H
#define CPP_PROJECT_READER_H
#include "json.hpp"

using namespace nlohmann;

class Reader {
public:
  explicit Reader() = default;
  static json read(const std::string &file_name);
};

#endif // CPP_PROJECT_READER_H
