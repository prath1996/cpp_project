#include "Sensor.h"
#include "json.hpp"
#include <fstream>
#include <stdlib.h>

using namespace nlohmann;

// ********************************************************************************************
// Sensor class functions
// ********************************************************************************************
Sensor::Sensor(const std::string &Name, const json &Data)
    : name(Name), data(Data) {}

void Sensor::sensor_info() const {
  std::cout << "Sensor name: " << name << std::endl;
}

// ********************************************************************************************
// Gyroscope class functions
// ********************************************************************************************
Gyroscope::Gyroscope(const std::string &Name, const json &Data,
                     const double &Thresh_start_stop, const double &Thresh_next,
                     const double &Thresh_prev)
    : Sensor(Name, Data) {
  thresh_start_stop = Thresh_start_stop;
  thresh_next = Thresh_next;
  thresh_prev = Thresh_prev;
  is_playing = true;
}

void Gyroscope::sensor_info() const {
  Sensor::sensor_info();
  std::cout << "Gyroscope sensor gives reading about angular velocity about "
               "X,Y and Z-axes\n\n";
}

void Gyroscope::check_start_stop(const int &cursor) {
  json row = data[cursor];
  Holder holder(row);
  if (holder.gyro_z >= thresh_start_stop) {
    if (is_playing) {
      std::cout << "Date-Time: " << holder.time << "| Pause music\n";
      is_playing = false;
    } else {
      std::cout << "Date-Time: " << holder.time << "| Play music\n";
      is_playing = true;
    }
  }
}

void Gyroscope::check_next(const int &cursor) {
  json row = data[cursor];
  Holder holder(row);
  if (holder.gyro_x <= -thresh_next) {
    std::cout << "Date-Time: " << holder.time << "| Play next song\n";
    is_playing = true;
  }
}

void Gyroscope::check_prev(const int &cursor) {
  json row = data[cursor];
  Holder holder(row);
  if (holder.gyro_x >= thresh_prev) {
    std::cout << "Date-Time: " << holder.time << "| Play previous song\n";
    is_playing = true;
  }
}

void Gyroscope::start_application() {
  for (int count = 0; count < data.size(); count++) {
    check_next(count);
    check_prev(count);
    check_start_stop(count);
  }
}

// ********************************************************************************************
// SoundSensor class functions
// ********************************************************************************************
SoundSensor::SoundSensor(const std::string &Name, const json &Data,
                         const double &Thresh_warning_mild,
                         const double &Thresh_warning_serious)
    : Sensor(Name, Data) {
  thresh_warning_mild = Thresh_warning_mild;
  thresh_warning_serious = Thresh_warning_serious;
}

void SoundSensor::sensor_info() const {
  Sensor::sensor_info();
  std::cout
      << "Sound sensor records the sound decibel levels using phone mic.\n\n";
}

void SoundSensor::check_sound_levels(const int &cursor) const {
  json row = data[cursor];
  Holder holder(row);
  if (holder.noise_level >= thresh_warning_serious) {
    std::cout << "Date-Time: " << holder.time
              << "| Sound(dB):" << holder.noise_level
              << "| Severe noise levels detected at Lat: " << holder.lat
              << " Long: " << holder.lon << "\n";
  } else if (holder.noise_level >= thresh_warning_mild) {
    std::cout << "Date-Time: " << holder.time
              << "| Sound(dB):" << holder.noise_level
              << "| Sound levels above safe limits\n";
  }
}

void SoundSensor::start_application() const {
  for (int count = 0; count < data.size(); count++) {
    check_sound_levels(count);
  }
}

Holder::Holder(json &row) {
  gyro_x = static_cast<double>(row.value("gyro_x", 0.0l));
  gyro_z = static_cast<double>(row.value("gyro_z", 0.0l));
  lat = static_cast<double>(row.value("lat", 0.0l));
  lon = static_cast<double>(row.value("long", 0.0l));
  noise_level = static_cast<double>(row.value("sound", 0.0l));
  time = row.value("time", "no_time_data_available");
}
