#include "reader.h"
#include "json.hpp"
#include <fstream>

using namespace nlohmann;

json Reader::read(const std::string &file_name) {
  std::ifstream data(file_name);
  return json::parse(data);
}