#ifndef CPP_PROJECT_SENSOR_H
#define CPP_PROJECT_SENSOR_H

#include "json.hpp"
#include <iostream>

using namespace nlohmann;

class Sensor {
private:
  std::string name;

protected:
  json data;
  Sensor(const std::string &, const json &);
  virtual void sensor_info() const;
};

class Gyroscope : Sensor {
  double thresh_start_stop;
  double thresh_next;
  double thresh_prev;
  static bool is_playing;

public:
  Gyroscope(const std::string &, const json &, const double &, const double &,
            const double &);
  void sensor_info() const override;
  void check_start_stop(const int &);
  void check_next(const int &);
  void check_prev(const int &);
  void start_application();
};

class SoundSensor : Sensor {
  double thresh_warning_mild;
  double thresh_warning_serious;

public:
  SoundSensor(const std::string &, const json &, const double &,
              const double &);
  void sensor_info() const override;
  void check_sound_levels(const int &) const;
  void start_application() const;
};

class Holder {
  friend SoundSensor;
  friend Gyroscope;
  double gyro_x;
  double gyro_z;
  double lat;
  double lon;
  double noise_level;
  std::string time;
  explicit Holder(json &);
};

#endif // CPP_PROJECT_SENSOR_H
