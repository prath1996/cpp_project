#include "Sensor.h"
#include "json.hpp"
#include "reader.h"
#include <iostream>

using namespace nlohmann;

bool Gyroscope::is_playing = false;

int main() {


  json gyro_data =
      Reader::read("data/testgyro.json");
  Gyroscope gyro("Gyroscope", gyro_data, 10.0, 10.0, 10.0);

  json sound_data =
      Reader::read("data/crash.json");
  SoundSensor soundSensor("Mic", sound_data, 95.0, 105.0);

  std::cout << "\nMUSIC PLAY/PAUSE AND SWITCH TO NEXT/PREVIOUS SONG BY GESTURE "
               "DETECTION USING GYROSCOPE\n\n";

  gyro.sensor_info();

  std::cout << "We are detecting sideways jerk to send inputs for playing and "
               "pausing the song.\n";
  std::cout << "Z-axis reading of gyroscope is being used for this since it "
               "shows sharp peaks during this motion.\n";
  std::cout << "If the Angular velocity exceeds the threshold value of 10 "
               "rad/s, the toggling happens.\n\n";
  std::cout << "We are detecting forwards and backwards flick to send inputs "
               "for switching the song.\n";
  std::cout << "X-axis reading of gyroscope is being used for this since it "
               "shows sharp peaks during this motion.\n";
  std::cout << "If the Angular velocity exceeds the threshold value of 10 "
               "rad/s, the switching happens.\n";
  std::cout << "Forward flick for next song and backward flick for previous "
               "song.\n\n\n";
  std::cout << "NOISE LEVEL ALARM\n\n";

  soundSensor.sensor_info();

  std::cout
      << "The phone's mic is used to continuously monitor sound decibels.\n";
  std::cout << "If sound level exceed 95dB, a warning is sent out informing "
               "that noise levels have crossed safety "
               "limits\n";
  std::cout << "If exceeds 110dB, a safety alarm is set off and messages are "
               "sent out to favourite contacts along "
               "with location data from GPS.\n\n\n";

  std::cout << "GYROSCOPE DEMONSTRATION\n";
  gyro.start_application();

  std::cout << "\n\nMIC DEMONSTRATION\n";
  soundSensor.start_application();

  return 0;
}
